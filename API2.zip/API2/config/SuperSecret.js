module.exports = {

    'secret' : 'MyNameIsTaha'

};
