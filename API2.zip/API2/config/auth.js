module.exports = {

    'facebookAuth' : {
        'clientID'      : '261618514224729', // your App ID
        'clientSecret'  : '508764cc06763127c099e5415e233d9f', // your App Secret
        'callbackURL'   : 'http://localhost:3000/auth/facebook/callback'
    }/*,

    'twitterAuth' : {
        'consumerKey'       : 'your-consumer-key-here',
        'consumerSecret'    : 'your-client-secret-here',
        'callbackURL'       : 'http://localhost:8080/auth/twitter/callback'
    },

    'googleAuth' : {
        'clientID'      : 'your-secret-clientID-here',
        'clientSecret'  : 'your-client-secret-here',
        'callbackURL'   : 'http://localhost:8080/auth/google/callback'
    }*/

};