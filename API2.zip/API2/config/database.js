module.exports = {

    //'url' : 'mongodb://localhost/db_name'
    'url' : 'mongodb://tahasiddiqui:sdd92201099@jello.modulusmongo.net:27017/puvEhy4t'//LOCAL0

};
